# WebZoo — Daniella Perez Cunha

Projeto acadêmico de Front-End — SENAI “Comendador Santoro Mirone” · 3º B · 2026

## Como abrir
1. Extraia o arquivo ZIP.
2. Abra a pasta no Visual Studio Code.
3. Abra `index.html` no navegador ou use a extensão Live Server.

O site é estático e não precisa instalar dependências.

## Páginas
- `index.html` — apresentação do WebZoo.
- `animais.html` — fichas de onça-pintada, tucano-toco e capivara, com filtros.
- `visite.html` — informações de visitação, tabela de ingressos, perguntas frequentes e previsão do tempo.
- `participe.html` — programas educativos e formulário demonstrativo.

## APIs utilizadas
- ViaCEP: https://viacep.com.br/ws/01001000/json/ — utilizada em `participe.html` para preencher rua, bairro, cidade e estado pelo CEP.
- Open-Meteo: https://api.open-meteo.com/v1/forecast — utilizada em `visite.html` para consultar temperatura e previsão na região do Zoológico de São Paulo.

As APIs precisam de conexão com a internet. Se uma consulta falhar, o site apresenta uma mensagem de erro.

## Interações
- Menu responsivo com botão hambúrguer, suporte a teclado e tecla Esc.
- Filtros por classe, alimentação e bioma.
- Perguntas frequentes expansíveis.
- Botão de voltar ao topo.
- Busca de CEP e preenchimento automático do endereço.
- Validação do formulário com mensagens por campo.
- Previsão do tempo com Open-Meteo.

## Tecnologias
HTML5, CSS3 e JavaScript puro. Fontes Playfair Display e DM Sans (Google Fonts; se estiver sem internet, serão usadas fontes alternativas).

## Observações
Os horários e valores de ingressos são fictícios e foram identificados como ilustrativos. O formulário não envia nem armazena dados. Não informe dados pessoais reais.

O diário de prompts acompanha o projeto. Ele registra o pedido de desenvolvimento e a solicitação de simplificação que foram efetivamente fornecidos nesta conversa; os campos sem prompt separado foram identificados com transparência, sem inventar registros.

## Publicação gratuita
O projeto pode ser publicado no GitHub Pages ou Netlify:
1. Crie uma conta no GitHub e um repositório.
2. Envie todos os arquivos desta pasta.
3. No GitHub, abra Settings → Pages.
4. Selecione a branch principal e a pasta raiz (`/root`) e salve.
5. Aguarde a publicação e teste o link em uma janela anônima e no celular.

Alternativa: arraste a pasta do projeto para https://app.netlify.com/drop.
